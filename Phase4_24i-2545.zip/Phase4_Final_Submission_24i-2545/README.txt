PHASE 4 - RESEARCH PAPER SUBMISSION

Muhammad Umair Ahmad | 24i-2545 | Section AI-C
Department of Artificial Intelligence
FAST NUCES, Islamabad, Pakistan
i242545@isb.nu.edu.pk

CONTENTS

Phase4_Research_Paper_24i-2545.pdf
  Research paper (12 pages).

LaTeX/
  Editable manuscript, bibliography, Springer Nature class and style,
  and all required figures with their editable sources.

Reproducibility/
  Original ARM64 Kathara image identity manifest and setup/evidence guide.
  Implementation and full experimental records are available at:
  https://github.com/Muhammad-Umair-Ahmad/Autonomous-Troubleshooting-Agents

COMPILING THE MANUSCRIPT

Overleaf: upload the contents of LaTeX/ and select paper.tex.
Local TeX Live, from LaTeX/:
  pdflatex paper.tex
  bibtex paper
  pdflatex paper.tex
  pdflatex paper.tex

SHA256.json contains integrity hashes for the included files.
