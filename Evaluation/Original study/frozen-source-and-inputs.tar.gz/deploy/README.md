# Upstream Linux deployment

Current macOS/Docker Desktop attempt is blocked: see `results/prerequisites/upstream-blocker.json`. A Linux container shares the Docker Desktop kernel; an image cannot supply missing VRF kernel support. A normal compatible Linux VM/host is needed for the complete upstream suite.

Use a free dedicated Linux host or locally provisioned Linux VM with Python 3.12+, Docker Engine 28 for FaulT-Bench compatibility, a VRF-capable kernel and at least 16 GB free disk plus results/build headroom. No paid cloud is required or authorized. This host currently lacks enough free storage for that full installation. Provisioning a VM requires freeing additional storage without deleting unrelated work.

1. Clone this project, install its locked Python dependencies, and clone upstream sources at the commits in `configs/sources.lock.json`. Never update a frozen experiment's source commit.
2. Check `uname -m`, Docker version and image architectures. Check `ip link add neta-vrf type vrf table 1234` with appropriate privileges, then delete only that temporary interface.
3. Read NIKA's pinned `docs/operations/installation.md`. Install prerequisites; run `./scripts/install.sh --skip-images` first. The upstream installer can change host settings and clean upstream image tags; use it only on the dedicated host after review. This project does not invoke its global cleanup helpers.
4. Prepare only the required scenario images initially. Use `nika env run dc_clos -s s`, then the pinned CLI's `failure inject`, `exec`, and owned `session close` lifecycle. Save successful baseline, injected root state, observable impact, restoration and cleanup evidence before counting a case validated.
5. For FaulT-Bench, install its pinned package from the sibling checkout and use its scenario parser. The project's adapter deliberately avoids upstream helpers that prune all Kathará networks or count all containers as a single lab. Real scenario-specific checks must have recognized, fail-closed expectations. The original paid agent/judge harness is not run.

`Dockerfile.linux` records the attempted nested environment. It is not a claim that a container replaces a VRF-capable VM. Nested `overlay2` failed; `vfs` worked but expanded disk usage significantly. Do not restart this attempt on a nearly full host.

## Verified dedicated-VM route

The separate VM resolved the earlier Docker Desktop kernel barrier. Portable Lima 2.3.0 was downloaded from the official release and SHA-256 verified. A pinned Ubuntu 24.04 ARM64 cloud image runs with 2 CPUs, 2 GiB RAM, a 22 GiB maximum disk, no host-folder mounts and no containerd service. Installing the matching linux-modules-extra package supplied VRF. `deploy/provision-research-vm.sh` installed and held Docker 28.5.2 inside this VM only.

Tool: `tools/lima/bin/limactl`. Persistent VM home: `/Users/muhammadumairahmad/Documents/Codex/neta-research-vm`. Instance: `neta-research`. The initial temporary guest source was cleared at restart; the runtime now uses persistent host VM storage and guest source `/opt/neta-research/vendor/nika`, with results under `/opt/neta-research/results`. A full stop/start/source/kernel/Docker probe passed; measured evidence is copied into the project. Do not assume its container IDs exist on a new host.

Pinned NIKA source was copied to `/tmp/neta-source/nika` inside the VM and installed using its normal installer with `--skip-images`. `nika env run dc_clos -s s` then built its required images and deployed eight containers. The normal NIKA session APIs validated services, an additional missing-IP variant, the published development DNS case and owned session cleanup. The FaulT-Bench check uses its copied Kath2 topology, immutable local image IDs, the installed Kathara Python API and strict observed impact expectations; it does not invoke global upstream pruning or paid agents.

Evidence: `results/upstream-nika-lifecycle-validation.json`, `results/upstream-faultbench-lifecycle-validation.json`, `results/prerequisites/lima-*.log` and `lima-final-environment.txt`. The failed initial FaulT-Bench CLI assumption is preserved in `results/upstream-faultbench-validation-attempt-1.json`; the successful validator uses the installed API.

The runtime is stopped before timed local main evaluation to avoid competing for the 8-GiB host memory. Restart only when coordinated with experiment ownership. These three published case lifecycle validations are not a complete upstream agent comparison; no unsupported scenario or missing agent run is counted successful.

The project `NikaAdapter` now uses `configs/upstream-runtime.json` and the dedicated VM, preserves the scenario/size on redeployment, and closes sessions with the actual `--session_id` CLI option. `scripts/neta upstream linux-probe` verifies the configured source commit, loaded VRF module and Docker 28. `results/upstream-adapter-live-persistent.json` records a real adapter deployment, DNS injection, fresh-session restoration and cleanup; `results/upstream-persistent-restart-probe.json` verifies persistence across stop/start. The earlier `/tmp` persistence failure is retained in `results/upstream-adapter-live.json`.
